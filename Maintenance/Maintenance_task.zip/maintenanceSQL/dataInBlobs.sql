SELECT count(*) FROM StreamData;

